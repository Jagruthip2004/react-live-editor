import React, { useState, useEffect, Suspense } from 'react';
import { Split, Package, Code2, Play } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

// Error Boundary Component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  render() {
    if (this.state.error) {
      return (
        <Alert variant="destructive" className="m-2">
          <AlertDescription className="font-mono text-sm">
            {this.state.error.message}
          </AlertDescription>
        </Alert>
      );
    }
    return this.props.children;
  }
}

// Default example code with hooks and interactivity
const DEFAULT_CODE = `function App() {
  const [count, setCount] = React.useState(0);
  const [text, setText] = React.useState('');
  
  return (
    <div className="p-6 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4 text-blue-600">
        Interactive Demo
      </h1>
      
      {/* Counter Example */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg">
        <p className="text-lg mb-2">Count: {count}</p>
        <button
          className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition-colors"
          onClick={() => setCount(c => c + 1)}
        >
          Increment
        </button>
      </div>
      
      {/* Input Example */}
      <div className="p-4 bg-gray-50 rounded-lg">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type something..."
          className="w-full p-2 border rounded-md mb-2"
        />
        {text && (
          <p className="text-gray-600">
            You typed: {text}
          </p>
        )}
      </div>
    </div>
  );
}`;

// Preview Component with proper error handling
const Preview = ({ code }) => {
  const [Component, setComponent] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    try {
      // Create and evaluate the component code
      const transformedCode = `
        ${code}
        return App;
      `;
      
      const ComponentFunction = new Function('React', transformedCode);
      const EvaluatedComponent = ComponentFunction(React);
      
      setComponent(() => EvaluatedComponent);
      setError(null);
    } catch (err) {
      setError(err);
      setComponent(null);
    }
  }, [code]);

  if (error) {
    return (
      <Alert variant="destructive" className="m-2">
        <AlertDescription className="font-mono text-sm whitespace-pre-wrap">
          {error.message}
        </AlertDescription>
      </Alert>
    );
  }

  if (!Component) {
    return null;
  }

  return (
    <ErrorBoundary>
      <Suspense fallback={<div>Loading preview...</div>}>
        <Component />
      </Suspense>
    </ErrorBoundary>
  );
};

// Main Editor Component
const LiveCodeEditor = () => {
  const [code, setCode] = useState(DEFAULT_CODE);
  const [packages, setPackages] = useState([]);
  const [newPackage, setNewPackage] = useState('');
  const [isInstalling, setIsInstalling] = useState(false);

  const handlePackageInstall = () => {
    if (!newPackage.trim()) return;
    
    setIsInstalling(true);
    setTimeout(() => {
      setPackages(prev => [...prev, newPackage.trim()]);
      setNewPackage('');
      setIsInstalling(false);
    }, 800);
  };

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b shadow-sm px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Split className="h-6 w-6 text-blue-600" />
          <h1 className="text-xl font-semibold text-gray-800">React Live Editor</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Package Manager */}
          <div className="flex items-center space-x-2">
            <Package className="h-4 w-4 text-gray-500" />
            <input
              type="text"
              value={newPackage}
              onChange={(e) => setNewPackage(e.target.value)}
              placeholder="Add package..."
              className="border rounded-md px-3 py-1.5 text-sm w-48 focus:outline-none focus:ring-2 focus:ring-blue-500"
              onKeyDown={(e) => e.key === 'Enter' && handlePackageInstall()}
            />
            <button
              onClick={handlePackageInstall}
              disabled={isInstalling || !newPackage.trim()}
              className="bg-blue-600 text-white px-3 py-1.5 rounded-md text-sm hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              {isInstalling ? 'Installing...' : 'Install'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Editor Panel */}
        <div className="w-1/2 border-r bg-white">
          <div className="h-full flex flex-col">
            <div className="border-b px-4 py-2 flex items-center space-x-2">
              <Code2 className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Editor</span>
            </div>
            <div className="flex-1 p-4">
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full h-full font-mono text-sm p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                spellCheck="false"
              />
            </div>
          </div>
        </div>

        {/* Preview Panel */}
        <div className="w-1/2 bg-white">
          <div className="h-full flex flex-col">
            <div className="border-b px-4 py-2 flex items-center space-x-2">
              <Play className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Preview</span>
            </div>
            <div className="flex-1 p-4 overflow-auto">
              <div className="min-h-full bg-white rounded-md border">
                <Preview code={code} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Package List */}
      {packages.length > 0 && (
        <div className="bg-gray-50 border-t px-4 py-2">
          <div className="flex items-center space-x-2">
            <Package className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-600">
              Installed: {packages.join(', ')}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};

export default LiveCodeEditor;