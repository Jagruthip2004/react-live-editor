import logo from './logo.svg';
import './App.css';
import LiveCodeEditor from './LiveCodeEditor';

function App() {
  return (
 <LiveCodeEditor></LiveCodeEditor>   
  );
}

export default App;
