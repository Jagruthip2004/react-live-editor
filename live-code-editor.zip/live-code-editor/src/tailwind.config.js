module.exports = {
    content: ['./*.html', './src/**/*.{js,jsx,ts,tsx}'], // Adjust to match your project structure
    theme: {
      extend: {},
    },
    plugins: [],
  };
  